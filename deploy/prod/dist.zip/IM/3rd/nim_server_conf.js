window.privateConf = {
  // lbs地址
  "lbs_web": "http://127.0.0.1/lbs/webconf.jsp",
  // 是否使用wss
  "link_ssl_web": false,
  // 上传地址
  "nos_uploader_web": "",
  // 是否使用https
  "https_enabled": false,
  // 下载地址
  "nos_downloader": "127.0.0.1/{bucket}/{object}",
  // 下载加速地址
  "nos_accelerate": "",
  "nos_accelerate_host": "",
  // 数据上报地址
  "nt_server": ""
}
